package com.example.flutter_proyecto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
